<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Husqvarna</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="ICON" href="img/Husky_Nomadic_Logo-2.png" type="image/ico" >
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <link href="css/my.css" rel="stylesheet">

  </head>

  <body id="page-top">

      <div class="container">
        <div class="row navigation align-content-top">
            <header>
                <div class="pioneering">
                    <span>Pioneering since 1903</span>
                </div>
                <div class="row nav-ba">
                <nav class="" role="navigation">
                    <div class="col-md-2 col-xs-2 logo">
                        <a class="navigation-logo" href="#"><img src="img/Husky_Nomadic_Logo-2.png"></a>
                    </div>
                    <div class="col-md-10 col-xs-10 list">
                        <ul>
                            <li>
                                <a class="list-bold" href="#">ENDURO</a>
                            </li>
                            <li>
                                <a class="list-bold" href="#">MOTOCROSS</a>
                            </li>
                            <li>
                                <a class="list-bold" href="#">SUPERMOTO</a>
                            </li>
                            <li>
                                <a class="list-bold" href="#">VITPILEN</a>
                            </li>
                            <li>
                                <a class="list-bold" href="#">SVARTPILEN</a>
                            </li>
                        </ul>
                        <div class="navigation-line"></div>
                    </div>
                    
                </nav>
                </div>
                
            </header>
        </div>
      </div>
      <div class="container-wide">
        <div class="nuur-img">
            <img src="img/Husqy%202.jpg">
            <h2>COMING <br> SOON</h2>
        </div>
      </div>
      
    <footer class="footer text-center">
        <ul class="footer-list list-footer uppercase">
            <li><a href="#">Contact</a></li>
            <li><a href="#">become a dealer</a></li>
            <li><a href="#">legal notices</a></li>
            <li><a href="#">imprint</a></li>
            <li><a href="#">privacy policy</a></li>
            <li><a href="#">careers</a></li>
            <li><a href="#">press</a></li>
            <li><a href="#">media</a></li>
        </ul>
        <div class="footer-buttons align-content-center">
            <a href="#" class="button-medium button-white button-grey">Dealer Search</a>
            <a href="#" class="button-medium button-white button-grey">Newsletter</a>
        </div>  
        <div class="footer-social-buttons align-content-center">
            <a href="https://www.facebook.com/husqvarnamongolia/" target="_blank" aria-label="Facebook" class="button-grey button-square"><div class="center-absolute sprite-facebook"></div></a>
            <a href="https://www.youtube.com/channel/UCJKXo4FfMhfAvS4OuR9J4Fg" target="_blank" aria-label="Youtube" class="button-grey button-square"><div class="center-absolute sprite-youtube"></div></a>
            <a href="https://www.instagram.com/husqvarnamongolia/" target="_blank" aria-label="Instagram" class="button-grey button-square"><div class="center-absolute sprite-instagram"></div></a>
        </div>
        <div class="footer-text">
            <p>
                © Husqvarna Mongolia All Rights Reserved
                <br>Coming Soon
            </p>
        </div>
    </footer>
      
      
      
  </body>
</html>
